/**
 * @usage 
 * @author 
 */

import { observable } from 'mobx';

export default class DemoModel {
    constructor() {
    } 
}