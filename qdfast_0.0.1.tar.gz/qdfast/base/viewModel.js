/**
 * @usage 
 * @author 
 */

import DemoModel from './model';
import { action } from 'mobx';
 
export default class DemoViewModel {
    constructor() {
        this.model = new DemoModel();
    }
}