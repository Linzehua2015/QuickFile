/**
 * @usage 
 * @author 
 */

// 系统
import React, { Component } from 'react';
import {
    Text,
    View
} from 'react-native';
// 三方
import { observer } from 'mobx-react/native';
// 业务
import styles from './styles';
import DemoViewModel from './viewModel';

@observer
export default class DemoPage extends Component<Props> {

    constructor(props) {
        super(props);
        this.viewModel = new DemoViewModel();
        this.model = this.viewModel.model;
    }

    render() {
        return (
            <View style={[styles.container, {justifyContent: 'center', alignItems: 'center'}]}>
                <Text style={{fontSize: 30}}>Demo</Text>
            </View>
        )
    }
}